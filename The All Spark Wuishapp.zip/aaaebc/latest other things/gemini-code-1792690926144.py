#!/usr/bin/env python3
"""
Trans-Symbolic Autonomic Continuum (Phase-VIII Python Architecture)
- Real-Time Recursive Singularity Synthesis & Topological Feedback
- NumPy Vectorized 4D Fractal Folding Engine
- Pygame Real-Time Display & PyAudio Dual-Channel Microtonal Worklet Engine
"""

import sys
import time
import math
import numpy as np

try:
    import pygame
except ImportError:
    print("Error: 'pygame' library is required. Install via: pip install pygame")
    sys.exit(1)

try:
    import pyaudio
    HAS_AUDIO = True
except ImportError:
    HAS_AUDIO = False
    print("Warning: 'pyaudio' library not found. Audio synthesis will be disabled. Install via: pip install pyaudio")


# =============================================================================
# RECURSIVE DUAL-CHANNEL MICROTONAL AUDIO SYNTHESIZER
# =============================================================================
class ContinuumAudioEngine:
    def __init__(self, sample_rate=44100):
        self.sample_rate = sample_rate
        self.num_ops = 32
        self.phases = np.zeros(self.num_ops, dtype=np.float64)
        self.mod_phases = np.zeros(self.num_ops, dtype=np.float64)

        self.base_freqs = np.array([
            18.25, 24.33, 27.37, 36.50, 48.66, 54.75, 73.00, 97.33,
            109.50, 146.00, 164.25, 194.66, 219.00, 246.00, 292.00, 328.50,
            365.00, 389.33, 438.00, 492.00, 584.00, 657.00, 730.00, 778.66,
            876.00, 984.00, 1095.00, 1168.00, 1314.00, 1460.00, 1557.33, 1752.00
        ], dtype=np.float64)

        # State Control Variables
        self.energy = 0.0
        self.warp = 0.5
        self.shock = 0.0
        self.stress = 0.0
        self.morph = 0.0
        self.singularity_drive = 0.0

        # Delay Buffer Configuration (Feedback Delay Network)
        self.delay_lens = [1381, 1811, 2239, 2699, 3119, 3637, 4219, 4933]
        self.delay_bufs = [np.zeros(88200, dtype=np.float32) for _ in range(8)]
        self.delay_ptrs = np.zeros(8, dtype=np.int32)
        self.filter_l = 0.0
        self.filter_r = 0.0

        self.pa = None
        self.stream = None

    def start(self):
        if not HAS_AUDIO:
            return
        try:
            self.pa = pyaudio.PyAudio()
            self.stream = self.pa.open(
                format=pyaudio.paFloat32,
                channels=2,
                rate=self.sample_rate,
                output=True,
                stream_callback=self._audio_callback,
                frames_per_buffer=512
            )
            self.stream.start_stream()
        except Exception as e:
            print(f"Audio stream error: {e}")

    def update_params(self, energy, warp, shock, stress, morph, drive):
        self.energy = energy
        self.warp = warp
        self.shock = shock
        self.stress = stress
        self.morph = morph
        self.singularity_drive = drive

    def _householder8(self, v):
        s = np.sum(v) * 0.25
        return v - s

    def _audio_callback(self, in_data, frame_count, time_info, status):
        out = np.zeros((frame_count, 2), dtype=np.float32)
        
        target_cut = min(0.99, max(0.005, (80.0 + self.energy * 9000.0 + self.shock * 6000.0) / 22050.0))
        op_indices = np.arange(self.num_ops, dtype=np.float64)
        
        # Audio frame loop synthesis
        for s in range(frame_count):
            recursive_mod = np.sin(self.singularity_drive * 0.05 + op_indices) * 4.2
            mod_idx = (7.0 + op_indices * 5.5 + recursive_mod) * (1.0 + self.energy * 4.5 + self.stress * 7.0)
            micro_shift = 1.0 + (self.warp * 0.16 * np.where(op_indices % 2 == 0, 1.0, -1.0)) + (self.singularity_drive * 0.001)
            freqs = self.base_freqs * micro_shift

            self.mod_phases += (freqs * 1.618033 * math.pi) / self.sample_rate
            mod_sig = np.sin(self.mod_phases) * mod_idx

            self.phases += ((freqs + mod_sig) * math.pi * 2.0) / self.sample_rate
            car_sig = np.sin(self.phases)
            car_sig = np.sin(car_sig * (1.15 + self.energy * 3.2 + self.shock * 6.0 + (self.singularity_drive * 0.01)))

            pan = (op_indices / 31.0) * 1.8 - 0.9
            amp = (0.032 - op_indices * 0.00075) * (1.0 + self.shock * 1.0)

            sum_l = np.sum(car_sig * amp * (0.5 - pan * 0.5))
            sum_r = np.sum(car_sig * amp * (0.5 + pan * 0.5))

            self.filter_l += (sum_l - self.filter_l) * target_cut
            self.filter_r += (sum_r - self.filter_r) * target_cut

            fdn_vec = np.zeros(8, dtype=np.float32)
            for ch in range(8):
                ptr = self.delay_ptrs[ch]
                fdn_vec[ch] = self.delay_bufs[ch][ptr]

            fdn_vec = self._householder8(fdn_vec)
            feedback = 0.88 + self.shock * 0.11 + (self.singularity_drive * 0.0002)

            for ch in range(8):
                ptr = self.delay_ptrs[ch]
                length = self.delay_lens[ch]
                in_sig = self.filter_l if ch % 2 == 0 else self.filter_r
                self.delay_bufs[ch][ptr] = in_sig * 0.38 + fdn_vec[ch] * feedback
                self.delay_ptrs[ch] = (ptr + 1) % length

            fdn_l = np.sum(fdn_vec[0::2])
            fdn_r = np.sum(fdn_vec[1::2])

            out[s, 0] = np.tanh(self.filter_l * 0.88 + fdn_l * 0.13)
            out[s, 1] = np.tanh(self.filter_r * 0.88 + fdn_r * 0.13)

        return (out.tobytes(), pyaudio.paContinue)

    def stop(self):
        if self.stream:
            self.stream.stop_stream()
            self.stream.close()
        if self.pa:
            self.pa.terminate()


# =============================================================================
# NUMPY VECTORIZED 4D FRACTAL & RAYMARCH RENDER ENGINE
# =============================================================================
class ContinuumRenderEngine:
    def __init__(self, width=320, height=200):
        self.width = width
        self.height = height

        # Framebuffers for Temporal Feedback and Scar Memory
        self.scar_memory = np.zeros((height, width, 4), dtype=np.float32)
        self.prev_frame = np.zeros((height, width, 3), dtype=np.float32)

        # Coordinate Grid Pre-calculation
        y, x = np.mgrid[-height//2:height//2, -width//2:width//2]
        aspect = width / height
        self.uv_x = (x / (height / 2.0))
        self.uv_y = -(y / (height / 2.0))
        self.r2 = self.uv_x**2 + self.uv_y**2

    def render(self, time_val, cam_pos, target_pos, energy, warp, shock, stress, morph, drive, interaction_pt, is_down):
        w, h = self.width, self.height

        # ---------------------------------------------------------------------
        # PASS 1: Scar Memory Accumulation
        # ---------------------------------------------------------------------
        dist_grid = np.sqrt((self.uv_x - interaction_pt[0])**2 + (self.uv_y - interaction_pt[1])**2)
        injection = np.clip(1.0 - dist_grid / 0.36, 0.0, 1.0) * (stress + shock * 2.0) if is_down else np.zeros_like(dist_grid)
        
        scar_update = np.zeros_like(self.scar_memory)
        scar_update[..., 0] = injection + np.sin(drive * 0.02 + self.uv_x * 6.28) * 0.02
        scar_update[..., 1] = shock
        scar_update[..., 2] = time_val * 0.1

        self.scar_memory = self.scar_memory * 0.82 + scar_update * 0.18
        self.scar_memory *= 0.9992

        # ---------------------------------------------------------------------
        # PASS 2: Vectorized Raymarch & Fractal Folding
        # ---------------------------------------------------------------------
        # Camera Ray Calculation
        ro = np.array(cam_pos, dtype=np.float32)
        ww = target_pos - ro
        ww /= np.linalg.norm(ww)
        uu = np.cross(ww, np.array([0.0, 1.0, 0.0], dtype=np.float32))
        uu /= np.linalg.norm(uu)
        vv = np.cross(uu, ww)

        # Ray directions
        rd_x = self.uv_x[..., None] * uu[0] + self.uv_y[..., None] * vv[0] + 1.6 * ww[0]
        rd_y = self.uv_x[..., None] * uu[1] + self.uv_y[..., None] * vv[1] + 1.6 * ww[1]
        rd_z = self.uv_x[..., None] * uu[2] + self.uv_y[..., None] * vv[2] + 1.6 * ww[2]
        rd = np.stack([rd_x, rd_y, rd_z], axis=-1)
        rd /= np.linalg.norm(rd, axis=-1, keepdims=True)

        # Raymarch loop initialization
        t = np.zeros((h, w), dtype=np.float32)
        active_mask = np.ones((h, w), dtype=bool)
        vol_scatter = np.zeros((h, w), dtype=np.float32)

        scale = 2.55 + warp * 0.65 + morph * 0.2 + math.sin(drive * 0.005) * 0.15
        scar_ref = self.scar_memory[..., 0]

        for step in range(24):  # Optimization for CPU execution
            if not np.any(active_mask):
                break

            p_x = ro[0] + rd[..., 0] * t
            p_y = ro[1] + rd[..., 1] * t
            p_z = ro[2] + rd[..., 2] * t

            # Morph & Deformation
            morph_shift_x = np.sin(time_val * 0.3 + p_z * morph)
            morph_shift_y = np.cos(time_val * 0.25 + p_x * morph)
            morph_shift_z = np.sin(time_val * 0.28 + p_y * morph)

            p_x += morph_shift_x * (0.35 + scar_ref * 0.5) * (morph + drive * 0.001)
            p_y += morph_shift_y * (0.35 + scar_ref * 0.5) * (morph + drive * 0.001)
            p_z += morph_shift_z * (0.35 + scar_ref * 0.5) * (morph + drive * 0.001)

            # SDF Estimation (Sphere-Box Hybrid)
            r_dist = np.sqrt(p_x**2 + p_y**2 + p_z**2)
            sphere_dist = r_dist - (1.95 + energy * 0.38)

            # Quaternion Box Fold
            q_x, q_y, q_z = p_x.copy(), p_y.copy(), p_z.copy()
            md2 = np.ones_like(r_dist)

            for _ in range(3):
                q_x = np.clip(q_x, -1.0, 1.0) * 2.0 - q_x
                q_y = np.clip(q_y, -1.0, 1.0) * 2.0 - q_y
                q_z = np.clip(q_z, -1.0, 1.0) * 2.0 - q_z

                r2 = q_x**2 + q_y**2 + q_z**2
                mask_low = (r2 < 0.25)
                mask_mid = (r2 >= 0.25) & (r2 < 1.0)

                q_x[mask_low] *= 4.0
                q_y[mask_low] *= 4.0
                q_z[mask_low] *= 4.0
                md2[mask_low] *= 4.0

                inv = 1.0 / np.maximum(r2[mask_mid], 1e-5)
                q_x[mask_mid] *= inv
                q_y[mask_mid] *= inv
                q_z[mask_mid] *= inv
                md2[mask_mid] *= inv

                q_x *= scale
                q_y *= scale
                q_z *= scale
                md2 *= scale

            box_dist = (np.sqrt(q_x**2 + q_y**2 + q_z**2) - 1.0) / np.abs(md2)
            
            # Smooth Minimum
            k = 0.38 + warp * 0.38
            h_dist = np.clip(0.5 + 0.5 * (box_dist - sphere_dist) / k, 0.0, 1.0)
            d = (1.0 - h_dist) * box_dist + h_dist * sphere_dist - k * h_dist * (1.0 - h_dist)

            vol_scatter += np.exp(-np.maximum(d, 0.0) * 4.5) * 0.03
            
            t += np.maximum(d * 0.4, 0.01)
            active_mask &= (np.abs(d) >= 0.002) & (t < 20.0)

        # Shading Composition
        color_r = np.sin(q_x * 0.2 + energy * 2.7) * 0.5 + 0.5
        color_g = np.cos(q_y * 0.2 + warp * 2.3) * 0.5 + 0.5
        color_b = np.sin(q_z * 0.2 + shock * 4.8) * 0.5 + 0.5

        img = np.stack([color_r, color_g, color_b], axis=-1)
        img += vol_scatter[..., None] * np.array([0.42, 0.13, 0.82])
        
        # ---------------------------------------------------------------------
        # PASS 3: Temporal Feedback
        # ---------------------------------------------------------------------
        decay = 0.89 + shock * 0.09 + morph * 0.03
        combined = img * 0.58 + self.prev_frame * decay * 0.42

        # Tonemapping (ACES approximation)
        col = (combined * (2.51 * combined + 0.03)) / (combined * (2.43 * combined + 0.59) + 0.14)
        col = np.clip(col, 0.0, 1.0)
        col = np.power(col, 1.0 / 2.2)

        self.prev_frame = col
        return (col * 255).astype(np.uint8)


# =============================================================================
# MAIN CONTROLLER & PYGAME APPLICATION LOOP
# =============================================================================
def main():
    pygame.init()
    
    # Low-resolution rendering buffer for real-time CPU raymarching performance
    render_w, render_h = 240, 150
    display_w, display_h = 960, 600

    screen = pygame.display.set_mode((display_w, display_h), pygame.RESIZABLE)
    pygame.display.set_caption("Trans-Symbolic Autonomic Continuum (Phase-VIII Python Engine)")
    clock = pygame.time.Clock()

    audio = ContinuumAudioEngine()
    audio.start()

    renderer = ContinuumRenderEngine(width=render_w, height=render_h)

    # State Variables
    cam_radius, target_radius = 6.2, 6.2
    cam_theta, target_theta = 0.65, 0.65
    cam_phi, target_phi = 1.05, 1.05
    vel_theta, vel_phi = 0.0, 0.0

    energy_val, target_energy = 0.0, 0.0
    warp_val, target_warp = 0.5, 0.5
    shock_val = 0.0
    stress_val = 0.0
    morph_val, target_morph = 0.0, 0.0
    singularity_drive = 0.0

    is_pointer_down = False
    last_x, last_y = 0, 0
    normalized_interaction = np.array([0.0, 0.0], dtype=np.float32)

    start_time = time.time()
    running = True

    while running:
        now = time.time() - start_time
        singularity_drive += 1.0 + (stress_val * 2.5)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_SPACE:
                    shock_val = 1.0
                    target_warp = (target_warp + 0.48) % 2.0
                    target_energy = 1.0
                    target_morph = 1.0

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    is_pointer_down = True
                    last_x, last_y = event.pos
                    vel_theta = 0.0
                    vel_phi = 0.0
                    normalized_interaction = np.array([
                        (event.pos[0] / display_w) * 2.0 - 1.0,
                        -((event.pos[1] / display_h) * 2.0 - 1.0)
                    ], dtype=np.float32)
                elif event.button == 4:  # Scroll Up
                    target_radius = max(2.0, target_radius - 0.5)
                elif event.button == 5:  # Scroll Down
                    target_radius = min(17.0, target_radius + 0.5)

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    is_pointer_down = False

            elif event.type == pygame.MOUSEMOTION:
                if is_pointer_down:
                    dx = event.pos[0] - last_x
                    dy = event.pos[1] - last_y
                    last_x, last_y = event.pos

                    normalized_interaction = np.array([
                        (event.pos[0] / display_w) * 2.0 - 1.0,
                        -((event.pos[1] / display_h) * 2.0 - 1.0)
                    ], dtype=np.float32)

                    vel_theta = -dx * 0.005
                    vel_phi = -dy * 0.005
                    target_theta += vel_theta
                    target_phi = max(0.05, min(math.pi - 0.05, target_phi + vel_phi))

                    vel = math.sqrt(dx * dx + dy * dy)
                    target_energy = min(1.0, target_energy + vel * 0.042)
                    stress_val = min(1.0, stress_val + vel * 0.028)
                    target_morph = min(1.0, target_morph + vel * 0.02)

            elif event.type == pygame.VIDEORESIZE:
                display_w, display_h = event.w, event.h

        # Update State Transformations
        if not is_pointer_down:
            target_theta += vel_theta
            target_phi = max(0.05, min(math.pi - 0.05, target_phi + vel_phi))
            vel_theta *= 0.95
            vel_phi *= 0.95

        cam_radius += (target_radius - cam_radius) * 0.08
        cam_theta += (target_theta - cam_theta) * 0.08
        cam_phi += (target_phi - cam_phi) * 0.08

        target_energy *= 0.93
        energy_val += (target_energy - energy_val) * 0.1
        warp_val += (target_warp - warp_val) * 0.05
        shock_val *= 0.90
        stress_val *= 0.92
        target_morph *= 0.94
        morph_val += (target_morph - morph_val) * 0.08

        # Sync Audio Worklet Parameters
        audio.update_params(energy_val, warp_val, shock_val, stress_val, morph_val, singularity_drive)

        # Camera Position Matrix
        cx = cam_radius * math.sin(cam_phi) * math.sin(cam_theta)
        cy = cam_radius * math.cos(cam_phi)
        cz = cam_radius * math.sin(cam_phi) * math.cos(cam_theta)
        cam_pos = (cx, cy, cz)
        target_pos = np.array([0.0, 0.0, 0.0], dtype=np.float32)

        # Render Frame
        frame_rgb = renderer.render(
            time_val=now,
            cam_pos=cam_pos,
            target_pos=target_pos,
            energy=energy_val,
            warp=warp_val,
            shock=shock_val,
            stress=stress_val,
            morph=morph_val,
            drive=singularity_drive,
            interaction_pt=normalized_interaction,
            is_down=is_pointer_down
        )

        # Surface Upscaling to Display Window
        surf = pygame.surfarray.make_surface(np.transpose(frame_rgb, (1, 0, 2)))
        scaled_surf = pygame.transform.smoothscale(surf, (display_w, display_h))
        screen.blit(scaled_surf, (0, 0))

        pygame.display.flip()
        clock.tick(60)

    audio.stop()
    pygame.quit()


if __name__ == "__main__":
    main()