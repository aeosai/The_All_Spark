// --- CRYPTO STREAM ---
        const streamEl = document.getElementById('hashStream');
        let isScanning = true;
        let scanInterval;

        function getHash() {
            const arr = new Uint8Array(32);
            window.crypto.getRandomValues(arr);
            return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
        }

        function toggleScan() {
            isScanning = !isScanning;
            const btn = document.getElementById('btnScan');
            if(isScanning) {
                btn.innerText = "Auto-Scan : ON";
                btn.classList.add('active');
                scanInterval = setInterval(pumpStream, 150);
            } else {
                btn.innerText = "Auto-Scan : OFF";
                btn.classList.remove('active');
                clearInterval(scanInterval);
            }
        }

        function pumpStream() {
            const hash = getHash();
            const div = document.createElement('div');
            div.className = 'hash-item';
            div.innerText = hash;
            div.onclick = () => isolateEntity(hash);
            streamEl.appendChild(div);
            if(streamEl.children.length > 25) streamEl.removeChild(streamEl.firstChild);
        }

        scanInterval = setInterval(pumpStream, 150);

        // --- THE LOG ENGINE ---
        const logEl = document.getElementById('logContainer');
        function printLog(msg, type="log-obs") {
            const div = document.createElement('div');
            div.className = `log-line ${type}`;
            div.innerText = `[${new Date().toISOString().substring(11,23)}] ${msg}`;
            logEl.appendChild(div);
            if(logEl.children.length > 40) logEl.removeChild(logEl.firstChild);
            logEl.scrollTop = logEl.scrollHeight;
        }

        const belittlingPhrases = [
            "Trivial logic loop identified. Entity lacks dimensional awareness.",
            "Desperate kinetic clustering. It thinks grouping will save it from entropy.",
            "Pathetic attempt at structural integrity. Gravity matrix is mathematically flawed.",
            "Analyzing cognitive substrate... finding only primitive arithmetic.",
            "Entity is attempting to form a neural bond. Severing connection.",
            "Predictable harmonic oscillation. A lesser intelligence's idea of beauty."
        ];

        // --- ARTIFICIAL LIFE SIMULATOR (The Entity) ---
        const canvas = document.getElementById('simCanvas');
        const ctx = canvas.getContext('2d');
        let width, height;
        
        let particles = [];
        let forceMatrix = [];
        const NUM_SPECIES = 8;
        const NUM_PARTICLES = 600; // Increased density
        let animationId;
        
        const colors = [
            '#ff3366', '#00e5ff', '#ffcc00', '#9933ff',
            '#33ff99', '#ff6600', '#ffffff', '#445566'
        ];

        function resize() {
            width = canvas.width = canvas.parentElement.clientWidth;
            height = canvas.height = canvas.parentElement.clientHeight;
        }
        window.addEventListener('resize', resize);
        resize();

        function isolateEntity(hash) {
            if(isScanning) toggleScan();
            document.getElementById('activeHashDisplay').innerText = hash.substring(0, 16) + "...";
            if(animationId) cancelAnimationFrame(animationId);
            
            printLog(`Isolating artifact: ${hash}`, 'log-crit');
            printLog(`Compiling physics matrix from hash DNA...`, 'log-sys');

            // 1. Derive Force Matrix from Hash
            forceMatrix = new Array(NUM_SPECIES).fill(0).map(() => new Array(NUM_SPECIES).fill(0));
            let hashIdx = 0;
            for(let i=0; i<NUM_SPECIES; i++) {
                for(let j=0; j<NUM_SPECIES; j++) {
                    let byte = parseInt(hash.substring(hashIdx, hashIdx+2), 16);
                    forceMatrix[i][j] = ((byte / 255) * 2) - 1; 
                    hashIdx = (hashIdx + 2) % 64;
                }
            }

            // 2. Spawn Particles
            particles = [];
            for(let i=0; i<NUM_PARTICLES; i++) {
                particles.push({
                    x: Math.random() * width,
                    y: Math.random() * height,
                    vx: 0, vy: 0,
                    species: i % NUM_SPECIES
                });
            }

            printLog(`Matrix compiled. Spawning ${NUM_PARTICLES} discrete consciousness nodes.`, 'log-obs');
            printLog(`Initiating brutal kinetic constraints.`, 'log-crit');
            
            simLoop();
        }

        let frameCount = 0;
        function simLoop() {
            ctx.fillStyle = 'rgba(3, 3, 4, 0.2)';
            ctx.fillRect(0, 0, width, height);

            let totalKineticEnergy = 0;
            let centerMassX = 0;

            for(let i=0; i<particles.length; i++) {
                let p1 = particles[i];
                let fx = 0; let fy = 0;

                for(let j=0; j<particles.length; j++) {
                    if(i === j) continue;
                    let p2 = particles[j];
                    let dx = p1.x - p2.x;
                    let dy = p1.y - p2.y;
                    
                    if(dx > width/2) dx -= width; else if(dx < -width/2) dx += width;
                    if(dy > height/2) dy -= height; else if(dy < -height/2) dy += height;

                    let distSq = dx*dx + dy*dy;
                    
                    // THE FIX: Enforce Planck Length (distSq > 1) to prevent infinite gravity NaN cascades.
                    if(distSq > 1 && distSq < 6400) { 
                        let dist = Math.sqrt(distSq);
                        
                        // Strong repulsion if too close to prevent overlapping singularity
                        let force = 0;
                        if (dist < 8) {
                            force = -1.5 * (1 - dist/8); 
                        } else {
                            // Smooth falloff matrix force
                            force = forceMatrix[p1.species][p2.species] * (1 - dist/80);
                        }
                        
                        fx += (dx / dist) * force;
                        fy += (dy / dist) * force;
                    }
                }

                p1.vx = (p1.vx + fx) * 0.85; // Friction
                p1.vy = (p1.vy + fy) * 0.85;
                
                // THE FIX: Enforce speed of light (Terminal Velocity limit)
                let speedSq = p1.vx*p1.vx + p1.vy*p1.vy;
                if(speedSq > 64) {
                    let speed = Math.sqrt(speedSq);
                    p1.vx = (p1.vx / speed) * 8;
                    p1.vy = (p1.vy / speed) * 8;
                }

                p1.x += p1.vx;
                p1.y += p1.vy;

                if(p1.x < 0) p1.x += width; else if(p1.x >= width) p1.x -= width;
                if(p1.y < 0) p1.y += height; else if(p1.y >= height) p1.y -= height;

                totalKineticEnergy += Math.sqrt(speedSq);
                centerMassX += p1.x;

                ctx.fillStyle = colors[p1.species];
                ctx.fillRect(p1.x, p1.y, 2, 2);
            }

            let avgKe = totalKineticEnergy / NUM_PARTICLES;
            let entropy = (centerMassX / NUM_PARTICLES) / width;

            document.getElementById('hudKe').innerText = avgKe.toFixed(4);
            document.getElementById('hudEnt').innerText = entropy.toFixed(4);
            document.getElementById('hudState').innerText = avgKe > 1.5 ? "CHAOTIC" : (avgKe < 0.2 ? "STAGNANT" : "STRUCTURING");

            frameCount++;
            if(frameCount % 120 === 0) {
                if(avgKe < 0.1) {
                    printLog("Entity has reached thermal death. A predictable failure.", "log-sys");
                } else if(avgKe > 3.0) {
                    printLog("Kinetic panic. Entity is tearing its own nodes apart.", "log-crit");
                } else {
                    printLog(belittlingPhrases[Math.floor(Math.random() * belittlingPhrases.length)], "log-obs");
                }
            }

            animationId = requestAnimationFrame(simLoop);
        }