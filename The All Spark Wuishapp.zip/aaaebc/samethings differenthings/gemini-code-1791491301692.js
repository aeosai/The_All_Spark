// harvest.js
const os = require('os');
const WebSocket = require('ws');

// Open a raw socket on port 8080
const wss = new WebSocket.Server({ port: 8080 });

console.log("APEX // NATIVE HARVEST ACTIVE ON PORT 8080");

wss.on('connection', (ws) => {
    console.log("BROWSER INTERFACE CONNECTED.");

    // Blast hardware telemetry to the browser every 50ms (20 times a second)
    const harvestLoop = setInterval(() => {
        const payload = {
            freeMem: os.freemem(),
            totalMem: os.totalmem(),
            cpuLoad: os.loadavg()[0], // 1-minute load average
            uptime: os.uptime(),
            // You can use child_process here to run terminal commands
            // like 'nvidia-smi' or 'sensors' and parse the raw output.
        };
        
        ws.send(JSON.stringify(payload));
    }, 50);

    ws.on('close', () => {
        console.log("BROWSER SEVERED.");
        clearInterval(harvestLoop);
    });
});