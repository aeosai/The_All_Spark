async function bootNativeBinary() {
    // 1. Define the WASI system call mappings
    const wasiImports = {
        wasi_snapshot_preview1: {
            fd_write: (fd, iovs, iovsLen, nwritten) => {
                // The browser intercepts a C-level file-descriptor write 
                // and redirects it to the browser console.
                console.log("Intercepted native system call.");
                return 0; // Return success code to the Wasm binary
            },
            // ... other POSIX system calls polyfilled here
        }
    };

    // 2. Stream and compile the raw binary directly into the V8 engine
    const { instance } = await WebAssembly.instantiateStreaming(
        fetch('native_program.wasm'),
        wasiImports
    );

    // 3. Execute the C program's main function directly in the browser
    instance.exports._start();
}