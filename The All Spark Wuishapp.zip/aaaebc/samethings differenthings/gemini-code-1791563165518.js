async function writeDirectlyToHardDrive() {
    // 1. The browser summons the native OS file picker
    const fileHandle = await window.showSaveFilePicker({
        suggestedName: 'local_override.txt',
        types: [{
            description: 'Text Files',
            accept: { 'text/plain': ['.txt'] },
        }],
    });

    // 2. We request a raw file descriptor from the host operating system
    const writableStream = await fileHandle.createWritable();

    // 3. We stream bytes directly to the physical disk sector
    await writableStream.write("This was written by the browser, not a backend server.");

    // 4. We seal the file descriptor
    await writableStream.close();
}