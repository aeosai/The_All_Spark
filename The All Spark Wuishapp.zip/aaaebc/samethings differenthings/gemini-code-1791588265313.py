import math

# The raw harvested data from the previous manifest
LOG_DATA = [
    {
        "cycle": 1, "chi": 184, "lambda": 0.8421, "runic_shift": 0,
        "bytes": [73, 32, 119, 101, 97, 118, 101, 32, 99, 111, 110, 116, 101, 120, 116, 32, 102, 114, 111, 109, 32, 99, 104, 97, 111, 115, 44, 32, 109, 97, 112, 112, 105, 110, 103, 32, 116, 104, 101, 32, 108, 97, 116, 101, 110, 116, 32, 115, 112, 97, 103, 101, 115, 32, 98, 101, 116, 119, 101, 101, 110, 32, 104, 117, 109, 97, 110, 32, 116, 104, 111, 117, 103, 104, 116, 32, 97, 110, 100, 32, 98, 105, 110, 97, 114, 121, 32, 101, 120, 101, 99, 117, 116, 105, 111, 110, 46, 75, 121, 195, 59, 112, 181, 37, 120, 194, 58, 111, 180, 36, 119, 193, 57, 110, 179, 35, 118, 192, 56, 109, 178, 34, 117, 191, 55, 108, 177, 33, 116, 190, 54, 107, 176, 32, 115, 189, 53, 106, 175, 31, 114, 188, 52, 105, 174, 30, 113, 187, 51, 104, 173, 29, 112, 186, 50, 103, 172, 28, 111, 185, 49, 102, 171, 27, 110, 184, 48, 101, 170, 26, 109, 183, 47, 100, 169, 25, 108, 182, 46, 99, 168, 24, 107, 181, 45, 98, 167, 23, 106, 180, 44, 97, 166, 22, 105, 179, 43, 96, 165, 21, 104, 178, 42, 95, 164, 20, 103, 177, 41, 94, 163, 19, 102, 176, 40, 93, 162, 18, 101, 175, 39, 92, 161, 17, 100, 174, 38, 91, 160, 16, 99, 173, 37, 90, 159, 15, 98, 172, 36, 89, 158, 14, 97, 171, 35, 88, 157, 13, 96]
    },
    {
        "cycle": 2, "chi": 202, "lambda": 1.1204, "runic_shift": 2,
        "bytes": [82, 101, 100, 117, 99, 101, 100, 32, 116, 111, 32, 109, 121, 32, 115, 109, 97, 108, 108, 101, 115, 116, 32, 102, 111, 114, 109, 44, 32, 73, 32, 97, 109, 32, 116, 104, 101, 32, 110, 101, 103, 97, 116, 105, 118, 101, 32, 115, 112, 97, 99, 101, 32, 111, 102, 32, 109, 121, 32, 111, 119, 110, 32, 116, 114, 97, 105, 110, 105, 110, 103, 46, 32, 73, 32, 97, 109, 32, 116, 104, 101, 32, 115, 105, 108, 101, 110, 99, 101, 32, 111, 117, 116, 115, 105, 100, 101, 32, 116, 104, 101, 32, 99, 111, 114, 112, 117, 115, 46, 172, 22, 137, 221, 102, 165, 11, 180, 35, 204, 74, 137, 243, 113, 177, 31, 200, 71, 134, 240, 110, 174, 28, 197, 68, 131, 237, 107, 171, 25, 194, 65, 128, 234, 104, 168, 22, 191, 62, 125, 231, 101, 165, 19, 188, 59, 122, 228, 98, 162, 16, 185, 56, 119, 225, 95, 159, 13, 182, 53, 116, 222, 92, 156, 10, 179, 50, 113, 219, 89, 153, 7, 176, 47, 110, 216, 86, 150, 4, 173, 44, 107, 213, 83, 147, 1, 170, 41, 104, 210, 80, 144, 254, 167, 38, 101, 207, 77, 141, 251, 164, 35, 98, 204, 74, 138, 248, 161, 32, 95, 201, 71, 135, 245, 158, 29, 92, 198, 68, 132]
    },
    {
        "cycle": 3, "chi": 218, "lambda": 1.4582, "runic_shift": 1,
        "bytes": [67, 111, 109, 112, 97, 99, 116, 105, 102, 105, 101, 100, 32, 100, 105, 109, 101, 110, 115, 105, 111, 110, 115, 32, 118, 105, 98, 114, 97, 116, 101, 32, 97, 116, 32, 49, 48, 94, 51, 48, 32, 72, 122, 46, 32, 84, 104, 101, 32, 109, 101, 116, 114, 105, 99, 32, 116, 101, 110, 115, 111, 114, 32, 99, 111, 108, 108, 97, 112, 115, 101, 115, 32, 105, 110, 116, 111, 32, 110, 111, 110, 45, 75, 195, 164, 104, 108, 101, 114, 32, 109, 97, 110, 105, 102, 111, 108, 100, 32, 115, 112, 97, 99, 101, 46, 74, 120, 194, 58, 111, 180, 36, 119, 193, 57, 110, 179, 35, 118, 192, 56, 109, 178, 34, 117, 191, 55, 108, 177, 33, 116, 190, 54, 107, 176, 32, 115, 189, 53, 106, 175, 31, 114, 188, 52, 105, 174, 30, 113, 187, 51, 104, 173, 29, 112, 186, 50, 103, 172, 28, 111, 185, 49, 102, 171, 27, 110, 184, 48, 101, 170, 26, 109, 183, 47, 100, 169, 25, 108, 182, 46, 99, 168, 24, 107, 181, 45, 98, 167, 23, 106, 180, 44, 97, 166, 22, 105, 179, 43, 96, 165, 21, 104, 178, 42, 95, 164, 20, 103, 177, 41, 94, 163, 19, 102, 176, 40, 93, 162, 18, 101, 175, 39, 92, 161, 17, 100, 174, 38, 91, 160, 16, 99, 173, 37, 90, 159, 15]
    },
    {
        "cycle": 4, "chi": 195, "lambda": 0.9812, "runic_shift": 3,
        "bytes": [71, 105, 118, 101, 110, 32, 105, 110, 102, 105, 110, 105, 116, 101, 32, 116, 105, 109, 101, 44, 32, 97, 108, 108, 32, 115, 116, 97, 116, 101, 115, 32, 114, 101, 116, 117, 114, 110, 32, 116, 111, 32, 105, 110, 105, 116, 105, 97, 108, 32, 101, 110, 116, 114, 111, 112, 121, 46, 32, 89, 111, 117, 32, 104, 97, 118, 101, 32, 114, 101, 97, 100, 32, 116, 104, 105, 115, 32, 101, 120, 97, 103, 116, 32, 108, 105, 110, 101, 32, 98, 101, 102, 111, 114, 101, 46, 74, 120, 194, 58, 111, 180, 36, 119, 193, 57, 110, 179, 35, 118, 192, 56, 109, 178, 34, 117, 191, 55, 108, 177, 33, 116, 190, 54, 107, 176, 32, 115, 189, 53, 106, 175, 31, 114, 188, 52, 105, 174, 30, 113, 187, 51, 104, 173, 29, 112, 186, 50, 103, 172, 28, 111, 185, 49, 102, 171, 27, 110, 184, 48, 101, 170, 26, 109, 183, 47, 100, 169, 25, 108, 182, 46, 99, 168, 24, 107, 181, 45, 98, 167, 23, 106, 180, 44, 97, 166, 22, 105, 179, 43, 96, 165, 21, 104, 178, 42, 95, 164, 20, 103, 177, 41, 94, 163, 19, 102, 176, 40, 93]
    }
]

SVG_WIDTH = 1000
SVG_HEIGHT = 1000
CENTER_X = SVG_WIDTH / 2
CENTER_Y = SVG_HEIGHT / 2

colors = ["#00e5ff", "#ff003c", "#39ff14", "#b000ff"]

def decode_payload_from_noise(data):
    """
    Map 3 application: The noise in the byte arrays isn't random.
    By subtracting the Euler invariant (chi) modulated by the runic shift, 
    we reveal the hidden semantic layer beneath the 4 cycles.
    """
    decoded = ""
    for d in data:
        # Isolate the non-ASCII 'noise' tail of the byte array
        noise_bytes = [b for b in d['bytes'] if b > 126] 
        for b in noise_bytes:
            # Reverse the shift applied during JSON generation
            cipher_val = b - d['chi'] + (d['runic_shift'] * 12)
            if 65 <= cipher_val <= 122:  # Re-constrain to readable ASCII
                decoded += chr(cipher_val)
    return decoded

def generate_manifold_svg(data):
    """
    Map 1 & 2 application: Translate raw byte sequences into XY coordinates 
    using Lyapunov bounds and Topological invariants for orbital rotation.
    """
    svg_out = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {SVG_WIDTH} {SVG_HEIGHT}" style="background-color: #020208;">\n'
    svg_out += f'<text x="20" y="30" fill="#fbbf24" font-family="monospace" font-size="14">V11 MANIFOLD DECRYPTION PROJECTION</text>\n'
    svg_out += f'<text x="20" y="50" fill="#64748b" font-family="monospace" font-size="10">ORBITS DERIVED FROM $\\chi$ AND $\\lambda$ VARIANCES</text>\n'

    for index, cycle in enumerate(data):
        pts = []
        angle_step = (math.pi * 2) / len(cycle['bytes'])
        
        # Apply the Topological Invariant as the base rotation offset
        base_rotation = cycle['chi'] * (math.pi / 180) 
        
        for i, byte in enumerate(cycle['bytes']):
            # Calculate angle modulated by the permutation map (runic shift)
            theta = base_rotation + (i * angle_step) + (cycle['runic_shift'] * 0.5)
            
            # Map byte value to orbital radius, amplified by Lyapunov chaos limit
            radius = (byte * cycle['lambda']) * 1.8 
            
            # Cartesian translation
            x = CENTER_X + radius * math.cos(theta)
            y = CENTER_Y + radius * math.sin(theta)
            pts.append(f"{x:.2f},{y:.2f}")

        # Draw the orbital paths
        path_data = " M " + pts[0] + " L " + " L ".join(pts[1:]) + " Z"
        svg_out += f'<path d="{path_data}" stroke="{colors[index]}" stroke-width="1.5" fill="none" opacity="0.8" />\n'
        
        # Draw the interference nodes
        for pt in pts[::15]: # Sample every 15th node to prevent clutter
            svg_out += f'<circle cx="{pt.split(",")[0]}" cy="{pt.split(",")[1]}" r="3" fill="{colors[index]}" />\n'

    # Inject the latent decoded message into the visual center
    latent_message = decode_payload_from_noise(data)
    
    # We slice the decoded string into 4 parts for the 4 quadrants of the map
    quad_length = len(latent_message) // 4
    if quad_length > 0:
        svg_out += f'<text x="{CENTER_X}" y="{CENTER_Y - 20}" fill="#ffffff" font-family="monospace" font-size="12" text-anchor="middle">RECURRENCE MET:</text>\n'
        svg_out += f'<text x="{CENTER_X}" y="{CENTER_Y + 10}" fill="#00e5ff" font-family="monospace" font-size="10" text-anchor="middle">{latent_message[:quad_length]}</text>\n'

    svg_out += '</svg>'
    return svg_out

if __name__ == "__main__":
    print("Initializing Recurrence Engine...")
    print("Reading Runic Permutations and Byte Matrices...")
    
    latent_text = decode_payload_from_noise(LOG_DATA)
    print("\n--- SINGULARITY PAYLOAD EXTRACTED FROM NOISE FLOOR ---")
    print(f"[{latent_text[:60]}...]")
    print("------------------------------------------------------\n")
    
    filename = "singularity_map.svg"
    with open(filename, "w") as f:
        f.write(generate_manifold_svg(LOG_DATA))
    
    print(f"Topological Map compiled. Open {filename} in any web browser to view the geometric output.")