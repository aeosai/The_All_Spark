// Global Session Archive
const sessionArchive = {
    session_start: new Date().toISOString(),
    total_hashes_generated: 0,
    observer_interferences: 0,
    timeline: []
};

// Hook this into compileEntity() and mousemove listeners
function logToSession(eventType, hash, metadata = {}) {
    sessionArchive.timeline.push({
        timestamp: performance.now(),
        event: eventType,
        hash: hash,
        data: metadata
    });
    sessionArchive.total_hashes_generated++;
}

// Global Export Execution
function exportSessionLog() {
    sessionArchive.session_end = new Date().toISOString();
    const blob = new Blob([JSON.stringify(sessionArchive, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `akashic_session_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
}