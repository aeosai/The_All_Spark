async function sendRawBytesToHardware() {
    // 1. The browser summons an OS-level prompt asking for hardware access
    const port = await navigator.serial.requestPort();
    
    // 2. We bypass the OS driver stack and open a direct 9600 baud channel
    await port.open({ baudRate: 9600 });
    
    // 3. We lock the write stream to stream data directly to the silicon
    const writer = port.writable.getWriter();
    
    // 4. Send a raw byte array directly to the hardware controller
    const data = new Uint8Array([104, 101, 108, 108, 111]); // "hello" in ASCII
    await writer.write(data);
    
    // Release the lock
    writer.releaseLock();
}