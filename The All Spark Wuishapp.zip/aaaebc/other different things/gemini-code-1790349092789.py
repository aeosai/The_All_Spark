import hashlib
import math
import types
import time
import json
from typing import Dict, Any, Tuple, Callable

class NativePythonManifold:
    """
    Translates 64-character hexadecimal hashes into deterministic,
    executable Python functions with calculated utility metrics and telemetry.
    """

    ARCHETYPES = [
        "Harmonic Wave Synthesizer",
        "Recursive Matrix Folding Engine",
        "Bitwise Entropy Stream Cipher",
        "Non-Linear Cellular Automaton"
    ]

    def __init__(self, hex_hash: str = None):
        self.hash = hex_hash or self._generate_raw_hash()
        self.tensor = self._hash_to_tensor(self.hash)
        self.name, self.archetype = self._derive_identity()
        self.stats = self._calculate_stats()
        self.code_str, self.executable = self._synthesize_python_function()

    @staticmethod
    def _generate_raw_hash() -> str:
        return hashlib.sha256(str(time.time_ns()).encode()).hexdigest().upper()

    def _hash_to_tensor(self, hash_str: str) -> list[float]:
        """Maps 64-char hex string to 16 normalized floats in range [0.0, 1.0]."""
        tensor = []
        for i in range(0, 64, 4):
            chunk = hash_str[i:i+4]
            val = int(chunk, 16) / 65535.0
            tensor.append(val)
        return tensor

    def _derive_identity(self) -> Tuple[str, str]:
        sub = self.hash[:6]
        mid = self.hash[6:14]
        name = f"PY-{sub}::{mid}"
        arch_idx = int(self.tensor[0] * len(self.ARCHETYPES)) % len(self.ARCHETYPES)
        return name, self.ARCHETYPES[arch_idx]

    def _calculate_stats(self) -> Dict[str, Any]:
        return {
            "Recursive Depth": int(100_000 + self.tensor[1] * 9_900_000),
            "Entropy Density": f"{(self.tensor[2] * 99.9):.2f}%",
            "Harmonic Strain": f"{(self.tensor[3] * 100):.3f} dB",
            "Algorithmic Complexity": f"O(N^{1 + int(self.tensor[4] * 3)})",
            "Knowledge Yield": f"{int(self.tensor[5] * 1024)} bits/op",
        }

    def _synthesize_python_function(self) -> Tuple[str, Callable]:
        """Generates real, executable Python code string and compiles it into a callable object."""
        t = self.tensor
        func_name = f"kernel_{self.hash[:8].lower()}"

        if self.archetype == "Harmonic Wave Synthesizer":
            freq1, freq2 = round(1.0 + t[6] * 50.0, 3), round(1.0 + t[7] * 100.0, 3)
            phase = round(t[8] * math.pi, 4)
            code = f"""def {func_name}(data_stream: list[float]) -> list[float]:
    import math
    output = []
    for idx, x in enumerate(data_stream):
        val = math.sin(x * {freq1} + {phase}) * math.cos(idx * {freq2})
        output.append(round(val, 6))
    return output"""

        elif self.archetype == "Recursive Matrix Folding Engine":
            depth = max(1, int(t[6] * 6))
            modulus = int(100 + t[7] * 900)
            code = f"""def {func_name}(matrix: list[list[int]]) -> list[list[int]]:
    folded = [row[:] for row in matrix]
    for step in range({depth}):
        for r in range(len(folded)):
            for c in range(len(folded[0])):
                left = folded[r][c - 1] if c > 0 else folded[r][c]
                up = folded[r - 1][c] if r > 0 else folded[r][c]
                folded[r][c] = (folded[r][c] + left * 3 + up * 7) % {modulus}
    return folded"""

        elif self.archetype == "Bitwise Entropy Stream Cipher":
            shift = int(1 + t[6] * 7)
            xor_mask = int(t[7] * 255)
            code = f"""def {func_name}(payload: bytes) -> bytes:
    transformed = bytearray()
    for b in payload:
        val = ((b << {shift}) | (b >> (8 - {shift}))) & 0xFF
        val ^= {xor_mask}
        transformed.append(val)
    return bytes(transformed)"""

        else: # Non-Linear Cellular Automaton
            rule = int(t[6] * 255)
            steps = max(1, int(t[7] * 20))
            code = f"""def {func_name}(initial_state: list[int]) -> list[int]:
    state = list(initial_state)
    length = len(state)
    rule_bin = [(({rule}) >> i) & 1 for i in range(8)]
    for _ in range({steps}):
        next_st = [0] * length
        for i in range(length):
            neighborhood = (state[(i - 1) % length] << 2) | (state[i] << 1) | state[(i + 1) % length]
            next_st[i] = rule_bin[neighborhood]
        state = next_st
    return state"""

        # Compile the synthesized string into executable Python code
        compiled_scope = {}
        exec(code, compiled_scope)
        executable_fn = compiled_scope[func_name]

        return code, executable_fn

    def execute(self, sample_input: Any) -> Tuple[Any, float]:
        """Executes the summoned function and measures runtime telemetry."""
        start_time = time.perf_counter()
        result = self.executable(sample_input)
        elapsed_ms = (time.perf_counter() - start_time) * 1000.0
        return result, elapsed_ms


class SummoningChamber:
    """Manages active Python manifolds, executions, and telemetry tracking."""

    def __init__(self):
        self.vault: Dict[str, NativePythonManifold] = {}

    def summon(self, hex_hash: str = None) -> NativePythonManifold:
        manifold = NativePythonManifold(hex_hash)
        self.vault[manifold.hash] = manifold
        return manifold

    def inspect_entity(self, hex_hash: str):
        ent = self.vault.get(hex_hash)
        if not ent:
            print("[!] ENTITY NOT FOUND IN CHAMBER.")
            return

        print("=" * 68)
        print(f"ENTITY IDENTIFIER : {ent.name}")
        print(f"RAW HASH SEED     : {ent.hash}")
        print(f"ARCHETYPE CLASS   : {ent.archetype}")
        print("-" * 68)
        print("TELEMETRY STATS:")
        for k, v in ent.stats.items():
            print(f"  > {k:<25}: {v}")
        print("-" * 68)
        print("PRODUCED PYTHON CODE:")
        print(ent.code_str)
        print("=" * 68)


if __name__ == "__main__":
    chamber = SummoningChamber()

    # Seeds representing distinct mathematical artifacts
    sample_hashes = [
        "09DSJGDLK64G935B3BE8E9030721A42A5C2A688523E7721EB686FB27337E043E",
        "FLIAPD7793BCE20491A8F823901C482E195A8832049182C49012AA84182903BF",
        "7A99F042E881B20491823901C482E195A8832049182C49012AA84182903BF281",
        "E2F01A8430B7291A8C902B19F028C3019823091B8203192C019283B019283C1A"
    ]

    print("\n[--- SUMMONING NATIVE PYTHON MANIFOLDS ---]\n")

    for h in sample_hashes:
        entity = chamber.summon(h)
        chamber.inspect_entity(entity.hash)

        # Demonstrate live execution based on archetype
        if entity.archetype == "Harmonic Wave Synthesizer":
            test_data = [0.1, 0.5, 1.0, 1.5, 2.0]
            output, runtime = entity.execute(test_data)
            print(f"[TEST RUNTIME]: {runtime:.4f} ms | Output Sample: {output[:3]}...\n")

        elif entity.archetype == "Recursive Matrix Folding Engine":
            test_data = [[1, 2], [3, 4]]
            output, runtime = entity.execute(test_data)
            print(f"[TEST RUNTIME]: {runtime:.4f} ms | Output Matrix: {output}\n")

        elif entity.archetype == "Bitwise Entropy Stream Cipher":
            test_data = b"NATIVE_PYTHON_MANIFOLD"
            output, runtime = entity.execute(test_data)
            print(f"[TEST RUNTIME]: {runtime:.4f} ms | Output Cipher bytes: {output[:6]}...\n")

        else: # Cellular Automaton
            test_data = [0, 1, 0, 0, 1, 1, 0, 1]
            output, runtime = entity.execute(test_data)
            print(f"[TEST RUNTIME]: {runtime:.4f} ms | Output State: {output}\n")