const http = require('http');

const PORT = 8080;

const server = http.createServer((req, res) => {
    
    // 1. Serve the Hypermedia Client Matrix
    if (req.url === '/' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Real Edge Hypermedia Matrix</title>
    <!-- Lightweight HTMX for true network hypermedia swaps -->
    <script src="https://unpkg.com/htmx.org@2.0.4"></script>
    <script src="https://unpkg.com/htmx-ext-sse@2.2.2"></script>
    <style>
        :root { --bg: #0a0a0c; --surface: #121216; --accent: #ff3366; --text: #f0f0f5; --success: #00ff66; }
        body { background: var(--bg); color: var(--text); font-family: system-ui, sans-serif; margin: 0; padding: 2.5rem; }
        .matrix-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.5rem; }
        .card { background: var(--surface); border: 1px solid #222; border-radius: 12px; padding: 1.5rem; }
        input, button { background: #1a1a22; color: var(--text); border: 1px solid #333; padding: 0.75rem; border-radius: 6px; width: 100%; box-sizing: border-box; margin-top: 0.5rem; }
        button { background: var(--accent); border: none; font-weight: 600; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Real Wire-Bound Hypermedia Matrix</h1>
    <main class="matrix-grid" hx-ext="sse" sse-connect="/api/telemetry">
        
        <!-- Real SSE Stream Connection -->
        <section class="card">
            <h2>Node-Alpha (Live Wire Stream)</h2>
            <div sse-swap="telemetry-update">
                <p>Establishing TCP/QUIC stream with server...</p>
            </div>
        </section>

        <!-- Real Server-Side Form Handling -->
        <section class="card">
            <h2>Deployment Vector</h2>
            <form hx-post="/api/deploy" hx-target="#deploy-feedback" hx-swap="outerHTML">
                <label for="zone">Target Zone:</label>
                <input type="text" id="zone" name="zone" value="mumbai-edge" required>
                <button type="submit">Execute Wire Deploy</button>
            </form>
            <div id="deploy-feedback"></div>
        </section>
    </main>
</body>
</html>`);
        return;
    }

    // 2. Real Server-Sent Events (SSE) Endpoint streaming HTML fragments over HTTP
    if (req.url === '/api/telemetry' && req.method === 'GET') {
        res.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive'
        });

        let counter = 0;
        const interval = setInterval(() => {
            counter++;
            const cpu = (Math.random() * 10 + 10).toFixed(1);
            // Push an actual HTML fragment down the socket over the wire
            res.write(`event: telemetry-update\n`);
            res.write(`data: <p>Status: <strong style="color: #00ff66;">Active (Tick ${counter} | CPU: ${cpu}%, Latency: 0.8ms)</strong></p>\n\n`);
        }, 2000);

        req.on('close', () => clearInterval(interval));
        return;
    }

    // 3. Real Server-Side POST Action returning targeted HTML Fragment
    if (req.url === '/api/deploy' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => { body += chunk; });
        req.on('end', () => {
            const params = new URLSearchParams(body);
            const zone = params.get('zone') || 'unknown';

            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
            // The server computes state and responds with pure HTML, not JSON
            res.end(`<div id="deploy-feedback" style="margin-top: 1rem; color: #00ff66;">
                ✓ Wire packet acknowledged. Cluster successfully deployed to <strong>${zone}</strong> at ${new.toISOString()}.
            </div>`);
        });
        return;
    }

    res.writeHead(404);
    res.end('Not Found');
});

server.listen(PORT, () => {
    console.log(`Hypermedia server running live at http://localhost:${PORT}`);
});