const http = require('http');

let clusterState = {
    nodes: [
        { id: 'london', name: 'London-Edge', cpu: 14.2, status: 'Optimal' },
        { id: 'mumbai', name: 'Mumbai-Edge', cpu: 28.5, status: 'Optimal' }
    ],
    deployments: []
};

const server = http.createServer((req, res) => {
    
    // 1. Serve the Native Hypermedia Client Document
    if (req.url === '/' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Native Edge Hypermedia Command Matrix</title>
    <style>
        :root { --bg: #070709; --surface: #111116; --accent: #ff3366; --text: #ededf2; --success: #00ff66; --border: #22222d; }
        body { background: var(--bg); color: var(--text); font-family: system-ui, -apple-system, sans-serif; margin: 0; padding: 3rem; }
        h1 { font-size: 1.5rem; letter-spacing: -0.03em; margin-bottom: 0.25rem; }
        p { color: #888899; margin-top: 0; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 1.5rem; margin-top: 2rem; }
        .card { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 1.75rem; }
        .card h2 { font-size: 1rem; color: #aaa; margin-top: 0; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 1px solid var(--border); padding-bottom: 0.75rem; }
        input, button { background: #181822; color: var(--text); border: 1px solid var(--border); padding: 0.75rem 1rem; border-radius: 6px; font-size: 0.9rem; width: 100%; box-sizing: border-box; margin-top: 0.5rem; }
        button { background: var(--accent); color: #fff; border: none; font-weight: 600; cursor: pointer; margin-top: 1rem; }
        button:hover { opacity: 0.9; }
        details { margin-top: 1rem; background: #0a0a0e; border: 1px solid var(--border); border-radius: 6px; padding: 0.75rem 1rem; }
        summary { cursor: pointer; font-weight: 500; color: #bbb; }
        [popover] { background: var(--surface); color: var(--text); border: 1px solid var(--accent); padding: 2rem; border-radius: 12px; }
        .pulse { display: inline-block; width: 8px; height: 8px; background: var(--success); border-radius: 50%; box-shadow: 0 0 8px var(--success); margin-right: 6px; }
        .telemetry-row { display: flex; justify-content: space-between; margin: 0.5rem 0; font-family: monospace; }
    </style>
</head>
<body>
    <header>
        <h1>Native Edge Command Matrix</h1>
        <p>Zero-dependency, wire-bound hypermedia engine communicating via native SSE and Fetch.</p>
    </header>

    <main class="grid">
        <!-- Node Telemetry Stream -->
        <section class="card">
            <h2>Cluster Telemetry Stream</h2>
            <div id="telemetry-feed">
                <p><span class="pulse"></span>Connecting to real SSE stream...</p>
            </div>
        </section>

        <!-- Deployment Form -->
        <section class="card">
            <h2>Deployment Vector</h2>
            <details>
                <summary>Configure New Deployment</summary>
                <form id="deploy-form">
                    <label for="zone">Target Zone:</label>
                    <input type="text" id="zone" name="zone" value="tokyo-edge" required>
                    <button type="submit">Engage Wire Deployment</button>
                </form>
            </details>
            <div id="deploy-feedback" style="margin-top: 1rem;" aria-live="polite"></div>
        </section>
    </main>

    <div style="margin-top: 2rem;">
        <button popovertarget="emergency-modal" style="width: auto; background: #1b1b24; border: 1px solid var(--border);">Emergency System Purge</button>
    </div>

    <div id="emergency-modal" popover>
        <h2>System Emergency Purge</h2>
        <p style="margin: 1rem 0; color: #aaa;">Terminating active edge sockets and flushing cache partitions.</p>
        <button onclick="triggerPurge()">Confirm Purge</button>
    </div>

    <script>
        // 1. Native EventSource (Zero third-party libraries)
        const source = new EventSource('/api/stream');
        
        source.addEventListener('telemetry', (e) => {
            document.getElementById('telemetry-feed').innerHTML = e.data;
        });

        // 2. Native Fetch Mutation (Injecting server-rendered HTML fragments)
        document.getElementById('deploy-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const feedback = document.getElementById('deploy-feedback');
            
            feedback.innerHTML = '<p style="color: #ffaa00;">Transmitting payload to edge server...</p>';
            
            const response = await fetch('/api/deploy', {
                method: 'POST',
                body: new URLSearchParams(formData)
            });
            
            // Server returns raw HTML fragment which gets injected directly
            const htmlFragment = await response.text();
            feedback.innerHTML = htmlFragment;
        });

        async function triggerPurge() {
            document.getElementById('emergency-modal').hidePopover();
            const response = await fetch('/api/purge', { method: 'POST' });
            const text = await response.text();
            alert(text);
        }
    </script>
</body>
</html>`);
        return;
    }

    // 2. Real Server-Sent Events (SSE) Stream Endpoint
    if (req.url === '/api/stream' && req.method === 'GET') {
        res.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive'
        });

        const timer = setInterval(() => {
            clusterState.nodes.forEach(n => {
                n.cpu = +(Math.random() * 15 + 10).toFixed(1);
            });

            // Construct real server-rendered HTML fragment
            let html = '';
            clusterState.nodes.forEach(n => {
                html += `<div class="telemetry-row">
                    <span><span class="pulse"></span>${n.name}</span>
                    <span style="color: var(--success);">CPU: ${n.cpu}% | Status: ${n.status}</span>
                </div>`;
            });

            res.write(`event: telemetry\n`);
            res.write(`data: ${html}\n\n`);
        }, 2000);

        req.on('close', () => clearInterval(timer));
        return;
    }

    // 3. Real Server POST Endpoint (Returning HTML Fragment)
    if (req.url === '/api/deploy' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            const params = new URLSearchParams(body);
            const zone = params.get('zone') || 'unknown';
            
            clusterState.deployments.push({ zone, time: new Date().toISOString() });

            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
            res.end(`<p style="color: var(--success); font-weight: 500;">✓ Edge ACK: Cluster successfully compiled and deployed to <strong>${zone}</strong> at ${new.toLocaleTimeString()}. Total deployments: ${clusterState.deployments.length}.</p>`);
        });
        return;
    }

    // 4. Purge Endpoint
    if (req.url === '/api/purge' && req.method === 'POST') {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('Edge cache purged successfully. State reset.');
        return;
    }

    res.writeHead(404);
    res.end('Not Found');
});

server.listen(8080, () => {
    console.log('Zero-dependency native hypermedia server running at http://localhost:8080');
});