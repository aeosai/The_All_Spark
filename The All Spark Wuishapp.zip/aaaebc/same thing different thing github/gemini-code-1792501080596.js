const URLNormalizer = (() => {
  function parseInput(input) {
    let clean = input.trim();

    // 1. Handle Shorthand Notation (e.g., "torvalds/linux")
    if (/^[a-zA-Z0-9_-]+\/[a-zA-Z0-9_.-]+$/.test(clean)) {
      return {
        type: 'REPO',
        apiUrl: `https://api.github.com/repos/${clean}`,
        ownerRepo: clean
      };
    }

    // 2. Handle GitHub Web URLs
    if (clean.includes('github.com')) {
      try {
        const url = new URL(clean.startsWith('http') ? clean : `https://${clean}`);
        const parts = url.pathname.split('/').filter(Boolean);

        if (parts.length >= 2) {
          const owner = parts[0];
          const repo = parts[1];
          const ownerRepo = `${owner}/${repo}`;

          // File Blob Link (e.g., github.com/owner/repo/blob/main/file.js)
          if (parts[2] === 'blob' && parts.length >= 5) {
            const branch = parts[3];
            const filePath = parts.slice(4).join('/');
            return {
              type: 'RAW_FILE',
              apiUrl: `https://raw.githubusercontent.com/${ownerRepo}/${branch}/${filePath}`,
              ownerRepo,
              filePath
            };
          }

          // Sub-tree Link (e.g., github.com/owner/repo/tree/main/src)
          if (parts[2] === 'tree' && parts.length >= 4) {
            const branch = parts[3];
            const treePath = parts.slice(4).join('/');
            return {
              type: 'SUB_TREE',
              apiUrl: `https://api.github.com/repos/${ownerRepo}/git/trees/${branch}?recursive=1`,
              ownerRepo,
              treePath
            };
          }

          // Standard Repository Root
          return {
            type: 'REPO',
            apiUrl: `https://api.github.com/repos/${ownerRepo}`,
            ownerRepo
          };
        }
      } catch (e) {
        // Fallback if URL parsing fails
      }
    }

    // 3. Direct API Link or Raw Web Endpoint Fallback
    return {
      type: 'DIRECT_API',
      apiUrl: clean,
      ownerRepo: clean
    };
  }

  return { parseInput };
})();